/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControllersdaTelaFuncionario;

import ViewPrincipal.TelaInicialVIEW;
import Views.Funcionario.TelaAtualizarSenhaFuncionarioVIEW;
import Views.Funcionario.TelaConsultarContratoFuncionarioVIEW;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class ControllerAtualizarSenhaFuncionario extends MouseAdapter{
    TelaAtualizarSenhaFuncionarioVIEW TASF = new TelaAtualizarSenhaFuncionarioVIEW();
    TelaConsultarContratoFuncionarioVIEW TCCF = new TelaConsultarContratoFuncionarioVIEW();
    public ControllerAtualizarSenhaFuncionario(TelaAtualizarSenhaFuncionarioVIEW telaatualizarsenhafuncionario) {
      this.TASF = telaatualizarsenhafuncionario;
      this.TASF.Panel_Atualizar.addMouseListener(this);
      this.TASF.Panel_Contrato.addMouseListener(this);
    
    
    }

    @Override
    public void mouseClicked(MouseEvent me) {
       if(me.getSource()==TASF.Panel_Atualizar){
           if(TASF.txtSenhaAntiga!=TASF.txtSenhaNova){
               //CHAMAR O DAO AQUI PARA ALTERAR SENHA NO BANCO
           }else {
               JOptionPane.showMessageDialog(null, "Senha ainda iguais.Digite Outra senha");
           }
           
       }else if(me.getSource()==TASF.Panel_Contrato){
           this.TCCF.setVisible(true);
           this.TASF.dispose();
           ControllerConsultarContratoFuncionario CTI = new ControllerConsultarContratoFuncionario(TCCF);
           
       }
      




    }

   
    
    
    
    
    
    
}
