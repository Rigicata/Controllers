/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControllersdaTelaFuncionario;

import Views.Funcionario.TelaAtualizarSenhaFuncionarioVIEW;
import Views.Funcionario.TelaConsultarContratoFuncionarioVIEW;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aluno
 */
public class ControllerConsultarContratoFuncionario extends MouseAdapter{
    TelaConsultarContratoFuncionarioVIEW TCCF = new TelaConsultarContratoFuncionarioVIEW();
    TelaAtualizarSenhaFuncionarioVIEW TASF = new TelaAtualizarSenhaFuncionarioVIEW();
    public ControllerConsultarContratoFuncionario(TelaConsultarContratoFuncionarioVIEW telaconsultarcontratoFuncionario) {
      this.TCCF = telaconsultarcontratoFuncionario;
      this.TCCF.label_PesquisarCPF.addMouseListener(this);
      this.TCCF.Painel_senha.addMouseListener(this);
      
      
      
    
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        
         if(me.getSource()==TCCF.label_PesquisarCPF){
                preencheTabelaporEMANDAMENTO(TCCF.tb_FuncionarioEmAdamento);
                preencheTabelaporCPFFEITO(TCCF.tb_FuncionarioFeito);
         }
       
        
        
        
        
        if(me.getSource()==TCCF.Painel_senha){
            
            this.TASF.setVisible(true);
            this.TCCF.dispose();
            ControllerAtualizarSenhaFuncionario CASF = new ControllerAtualizarSenhaFuncionario ();
            
        }











    }
    
     public void preencheTabelaporEMANDAMENTO(JTable tabela){ 
    DefaultTableModel tabelado = new DefaultTableModel();
    tabela.setModel(tabelado);
    
        tabelado.addColumn("ID Contrato");
        tabelado.addColumn("CNPJ(EMPRESA)");
        tabelado.addColumn("CPF");
        tabelado.addColumn("Dia Inicial");
        tabelado.addColumn("Dia Final");
        tabelado.addColumn("Horário Inicial");
        tabelado.addColumn("Horário Final");
        tabelado.addColumn("Localização");
        tabelado.addColumn("Tipo");
        tabelado.addColumn("Cláusulas");
        Object[] coluna = new Object[10];
        ArrayList<Contrato> contratos = cDAO.pesquisarContratoporCPFemAndamento();
        for(int i=0;i<contratos.size();i++){
            coluna[0] = contratos.get(i).getId();
            coluna[1] = contratos.get(i).getCnpj_Empresa();
            coluna[2] = contratos.get(i).getCpf_Funcionario();
            coluna[3] = contratos.get(i).getDiaincial();
            coluna[4] = contratos.get(i).getDiafinal();
            coluna[5] = contratos.get(i).getHorarioinicial();
            coluna[6] = contratos.get(i).getHorariofinal();
            coluna[7] = contratos.get(i).getLocalizacao();
            coluna[8] = contratos.get(i).getTipo();
            coluna[9] = contratos.get(i).getClausula();
           
            
           tabelado.addRow(coluna);
          
              
              
          }
         tabela.setModel(tabelado);
    }


        
    public void preencheTabelaporCPFFEITO(JTable tabela){
         DefaultTableModel tabelado = new DefaultTableModel();
         tabela.setModel(tabelado);
        tabelado.addColumn("ID Contrato");
        tabelado.addColumn("CNPJ(EMPRESA)");
        tabelado.addColumn("CPF");
        tabelado.addColumn("Dia Inicial");
        tabelado.addColumn("Dia Final");
        tabelado.addColumn("Horário Inicial");
        tabelado.addColumn("Horário Final");
        tabelado.addColumn("Localização");
        tabelado.addColumn("Tipo");
        tabelado.addColumn("Horário Inicial");
        Object[] coluna = new Object[10];
          ArrayList<Contrato>contratos = cDAO.pesquisarContratoporCPFfeito();
            
           
            for(int i=0;i<contratos.size();i++){
            coluna[0] = contratos.get(i).getId();
            coluna[1] = contratos.get(i).getCnpj_Empresa();
            coluna[2] = contratos.get(i).getCpf_Funcionario();
            coluna[3] = contratos.get(i).getDiaincial();
            coluna[4] = contratos.get(i).getDiafinal();
            coluna[5] = contratos.get(i).getHorarioinicial();
            coluna[6] = contratos.get(i).getHorariofinal();
            coluna[7] = contratos.get(i).getLocalizacao();
            coluna[8] = contratos.get(i).getTipo();
            coluna[9] = contratos.get(i).getClausula();
           
            
           tabelado.addRow(coluna);
           
              
              
          } 
           tabela.setModel(tabelado);
        
        
    }
    
    
    
}
