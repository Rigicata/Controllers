/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControllersdaTelaFuncionario;

import ViewPrincipal.TelaInicialVIEW;
import Views.Funcionario.TelaConsultarContratoFuncionarioVIEW;
import Views.Funcionario.TelaLoginFuncionarioVIEW;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class ControllerLoginFuncionario extends MouseAdapter{
    
    TelaLoginFuncionarioVIEW TLF = new TelaLoginFuncionarioVIEW();
    TelaInicialVIEW TI= new TelaInicialVIEW();
    TelaConsultarContratoFuncionarioVIEW TCCF = new TelaConsultarContratoFuncionarioVIEW();
    public ControllerLoginFuncionario(TelaLoginFuncionarioVIEW TelaloginFuncionario,TelaConsultarContratoFuncionarioVIEW telaconsultarcontratofuncionario) {
    this.TLF = TelaloginFuncionario;
    this.TCCF =telaconsultarcontratofuncionario;
    this.TLF.Painel_Entrar.addMouseListener(this);
    this.TLF.Painel_Voltar.addMouseListener(this);
    
    
    }

    @Override
    public void mouseClicked(MouseEvent me) {
       
        
        if(me.getSource()==TLF.Painel_Entrar){
            if(verificaLogin(TLF.ftCPF.getText(),TLF.txtSenha.getPassword())){
                this.TCCF.setVisible(true);
                this.TLF.dispose();
                ControllerConsultarContratoFuncionario CCCF= new ControllerConsultarContratoFuncionario();
                
                
                
            }else {
                JOptionPane.showMessageDialog(null, "Senha ou usuário incorretos");
            }
            
            
        }else if(me.getSource()==TLF.Painel_Voltar){
            this.TI.setVisible(true);
            this.TLF.dispose();
            ControllerTelaInicial CTI = new ControllerTelaInicial();
            
        }
        
        
        
        
        
    }
    
    
    
    
    
    
    
}
