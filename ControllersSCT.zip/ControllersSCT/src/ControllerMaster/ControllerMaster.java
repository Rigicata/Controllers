package ControllerMaster;


import controller.ControllerEmpresa.EmpresaController;
import controller.ControllerFuncionario.FuncionarioController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import views.Principal.TelaInicialVIEW;
import views.ViewsEmpresa.TelaLoginEmpresaVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;
import views.ViewsFuncionario.TelaLoginFuncionarioVIEW;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class ControllerMaster extends MouseAdapter {

    TelaInicialVIEW TI = new TelaInicialVIEW();
    
    
    public ControllerMaster(TelaInicialVIEW TELAI){
        TI = TELAI;
        this.TI.Painel_Empresa.addMouseListener(this);
        this.TI.Painel_Funcionario.addMouseListener(this);
        //this.TI.btnTeste.addActionListener(this);
        //TI.setVisible(true);
    }
    
  
    
   @Override
   public void mouseClicked (MouseEvent e){
       
       //TelaInicialVIEW TI = new TelaInicialVIEW();
      //TI.setVisible(true);
       if(e.getSource()==TI.Painel_Empresa){
            TelaLoginEmpresaVIEW TLE = new TelaLoginEmpresaVIEW();
            TLE.setVisible(true);
            TI.dispose();
            EmpresaController EC = new EmpresaController(TLE);
        }else if(e.getSource()==TI.Painel_Funcionario){
            TelaLoginFuncionarioVIEW TLF = new TelaLoginFuncionarioVIEW();
            TLF.setVisible(true);
            TI.dispose();
            FuncionarioController FC = new FuncionarioController(TLF);
        }
        

   }

 
        
   
        
    
    }


  

